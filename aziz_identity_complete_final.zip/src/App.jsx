
export default function App() {
  return (
    <div style={{ fontFamily: 'Tahoma', textAlign: 'center', padding: '50px' }}>
      <h1>🚧 الموقع قيد البناء النهائي حسب المواصفات الكاملة</h1>
      <p>سيتم إرساله كاملاً خلال دقائق.</p>
    </div>
  );
}
